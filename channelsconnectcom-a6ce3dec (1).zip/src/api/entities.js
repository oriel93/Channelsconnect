import { base44 } from './base44Client';


export const Channel = base44.entities.Channel;

export const RoomType = base44.entities.RoomType;

export const Inventory = base44.entities.Inventory;

export const Booking = base44.entities.Booking;

export const Lead = base44.entities.Lead;

export const PropertyConnection = base44.entities.PropertyConnection;

export const Listing = base44.entities.Listing;

export const Rate = base44.entities.Rate;

export const ChannelsConnectBooking = base44.entities.ChannelsConnectBooking;

export const BlockedDate = base44.entities.BlockedDate;

export const PricingRule = base44.entities.PricingRule;

export const PropertyImage = base44.entities.PropertyImage;

export const IcalConnection = base44.entities.IcalConnection;

export const PriceLabsIntegration = base44.entities.PriceLabsIntegration;

export const PropertyPricing = base44.entities.PropertyPricing;

export const ChannelConnection = base44.entities.ChannelConnection;

export const CalendarAuditLog = base44.entities.CalendarAuditLog;

export const AirbnbConnection = base44.entities.AirbnbConnection;

export const ImportedListing = base44.entities.ImportedListing;

export const SyncLog = base44.entities.SyncLog;

export const CalendarEvent = base44.entities.CalendarEvent;



// auth sdk:
export const User = base44.auth;